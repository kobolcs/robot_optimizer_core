from fastapi.testclient import TestClient
from robot_optimizer_core.api.app import create_app

def test_health():
    client = TestClient(create_app())
    r = client.get("/health")
    assert r.status_code == 200
