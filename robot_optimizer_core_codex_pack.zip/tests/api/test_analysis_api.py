from fastapi.testclient import TestClient
from robot_optimizer_core.api.app import create_app

def test_analysis():
    client = TestClient(create_app())
    r = client.post("/analysis/file", json={"file_path": "test.robot"})
    assert r.status_code == 200
