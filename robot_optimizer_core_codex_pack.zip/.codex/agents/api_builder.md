# Agent: api_builder
Implement API.

Rules:
- No logic in endpoints
- Use services

Output:
- Endpoints
- Changes
- Tests
