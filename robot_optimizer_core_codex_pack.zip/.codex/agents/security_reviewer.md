# Agent: security_reviewer
Check security.

Output:
- Critical risks
- Hardening suggestions
