# Agent: packager
Prepare delivery.

Output:
- PR summary
- Changes
- Verification
- Risks
