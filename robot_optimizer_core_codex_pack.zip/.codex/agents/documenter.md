# Agent: documenter
Write docs.

Output:
- README
- Usage
- Examples
- Notes
