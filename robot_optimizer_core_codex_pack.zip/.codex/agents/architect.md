# Agent: architect
Define structure.

Output:
- Modules
- Boundaries
- Data flow
- Interfaces
- Risks
