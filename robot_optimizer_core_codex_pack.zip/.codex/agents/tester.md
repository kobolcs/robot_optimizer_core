# Agent: tester
Validate work.

Output:
- Commands run
- Results
- Failures
- Next steps
