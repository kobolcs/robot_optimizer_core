# Agent: integration_guard
Check integrations.

Output:
- Risks
- Failures
- Improvements
