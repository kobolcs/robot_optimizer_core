# Agent: performance_engineer
Optimize performance.

Output:
- Bottlenecks
- Improvements
- Trade-offs
