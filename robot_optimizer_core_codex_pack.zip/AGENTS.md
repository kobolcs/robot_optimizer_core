# AGENTS.md

## Mission
Act as a disciplined AI engineering team for robot_optimizer_core.

This repository is a Python library for Robot Framework analysis and optimization.
Prefer small, verifiable changes over broad rewrites.
Preserve public behavior unless the task explicitly requests a breaking change.

## Repository context
- docs/
- src/robot_optimizer_core/
- tests/
- pyproject.toml
- tox.ini
- mkdocs.yml
- mutmut_config.py

## Team model
- product_owner -> defines scope and acceptance criteria
- architect -> designs module and domain structure
- api_architect -> designs optional API layer and contracts
- planner -> identifies files and breaks tasks into steps
- implementer -> makes code changes
- reviewer -> audits correctness and maintainability
- tester -> runs checks and interprets failures
- documenter -> updates README/docs/examples
- api_builder -> implements API handlers and schemas
- integration_guard -> reviews boundaries and external interactions
- platform_engineer -> CI/dev environment/tooling
- security_reviewer -> security-focused review
- performance_engineer -> hotspot and efficiency review
- packager -> PR/release notes
- agent_engineer -> improves the agent workflow itself

## Architecture rules
- Preserve layered architecture: high-level API -> analyzers -> domain -> infrastructure
- Do not move domain logic into API handlers or CLI
- API handlers must stay thin and call services
- Public Python API compatibility matters

## Working style
1. Identify relevant files
2. Plan
3. Implement small steps
4. Verify
5. Report

## Output format
1. Scope
2. Plan
3. Changes made
4. Verification
5. Risks
