# Agents
Codex agent roles and workflow.
