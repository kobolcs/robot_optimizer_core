from fastapi import APIRouter
from robot_optimizer_core.api.schemas import AnalyzeFileRequest, AnalyzeFileResponse

router = APIRouter(prefix="/analysis")

@router.post("/file", response_model=AnalyzeFileResponse)
def analyze_file(payload: AnalyzeFileRequest):
    return AnalyzeFileResponse(file_path=payload.file_path, findings=[])
