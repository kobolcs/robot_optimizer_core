from fastapi import APIRouter
from robot_optimizer_core.api.schemas import HealthResponse

router = APIRouter()

@router.get("/health", response_model=HealthResponse)
def health():
    return HealthResponse()
