from fastapi import FastAPI

from robot_optimizer_core.api.routes.health import router as health_router
from robot_optimizer_core.api.routes.analysis import router as analysis_router


def create_app() -> FastAPI:
    app = FastAPI(title="robot_optimizer_core API")
    app.include_router(health_router)
    app.include_router(analysis_router)
    return app


app = create_app()
