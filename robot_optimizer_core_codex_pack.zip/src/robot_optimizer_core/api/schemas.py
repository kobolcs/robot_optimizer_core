from pydantic import BaseModel


class HealthResponse(BaseModel):
    status: str = "ok"


class AnalyzeFileRequest(BaseModel):
    file_path: str


class AnalyzeFileResponse(BaseModel):
    file_path: str
    findings: list
